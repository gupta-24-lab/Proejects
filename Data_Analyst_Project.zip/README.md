# 📊 Data Analyst Portfolio Project (SQL + Power BI)

## 📌 Overview
This project demonstrates end-to-end data analysis using SQL and Power BI.

## 🎯 Objectives
- Analyze sales/COVID trends
- Build KPIs and dashboards
- Showcase SQL + BI skills

## 🛠 Tools
- SQL
- Power BI
- Excel

## 📂 Structure
- data/ -> raw datasets
- sql/ -> SQL scripts
- powerbi/ -> dashboard files
- docs/ -> documentation

## 🚀 Steps
1. Load dataset into SQL
2. Run SQL queries
3. Connect Power BI
4. Build dashboard

## 📊 Key Insights
- Trend analysis
- KPI metrics
- Country/business comparison

## 👤 Author
Abhishek Chauhan

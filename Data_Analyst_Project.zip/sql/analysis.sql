-- KPI Analysis
SELECT location,
SUM(total_cases) as total_cases,
SUM(total_deaths) as total_deaths,
(SUM(total_deaths)/SUM(total_cases))*100 as death_rate
FROM covid_data
GROUP BY location
ORDER BY death_rate DESC;

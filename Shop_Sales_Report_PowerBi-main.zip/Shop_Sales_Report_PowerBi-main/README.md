# Shop Sales Report (Power BI)

This project contains retail **shop sales** data for **2018** and supporting assets to build or present a **Power BI** dashboard: orders and line-level details, a sample **`.pbix`** file, and **dashboard preview images** stored in this folder.

## Datasets (`Datasets/`)

| File | Description |
|------|-------------|
| `Orders.csv` | One row per **order**: order id, date, customer, **state**, **city**. |
| `Details.csv` | One row per **line item**: links to orders via **Order ID**; **amount**, **profit**, **quantity**, **category**, **sub-category**, **payment mode**. |

**Suggested relationship in Power BI:** `Orders[Order ID]` → `Details[Order ID]` (one-to-many).

### `Orders.csv` columns

`Order ID`, `Order Date`, `CustomerName`, `State`, `City`

### `Details.csv` columns

`Order ID`, `Amount`, `Profit`, `Quantity`, `Category`, `Sub-Category`, `PaymentMode`

### Example measures (DAX)

- **Total sales:** `SUM(Details[Amount])`
- **Total profit:** `SUM(Details[Profit])`
- **Order count:** `DISTINCTCOUNT(Details[Order ID])` or `COUNTROWS(Orders)` when the grain is one row per order
- **Units sold:** `SUM(Details[Quantity])`

## Power BI file

- **`Sales-Dashboard-shop.pbix`** — open in **Power BI Desktop** to explore or extend the report.

## Dashboard images (in this folder)

Preview images below live **in the same directory as this README** (no external links required).

### KPIs and sales by month

![KPI cards and monthly sales trend](powerbi-shop-sales-kpi-monthly.png)

### Category mix and top states

![Sales by category and top states](powerbi-shop-sales-category-state.png)

### Payment modes and category amount vs profit

![Payment mix and profitability by category](powerbi-shop-sales-payment-profit.png)

### Original dashboard export

![Sales dashboard (original export)](Sales-dashboard-shop.png)

---

Use **Get Data → Text/CSV** (or folder) in Power BI Desktop, point to `Datasets/`, confirm types (dates, numbers), create the relationship above, then add visuals and slicers for **State**, **City**, **Category**, **Sub-Category**, **PaymentMode**, and **Order Date**.
